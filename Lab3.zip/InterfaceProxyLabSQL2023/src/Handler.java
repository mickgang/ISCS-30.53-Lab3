import java.lang.reflect.*;
import java.util.*;
import annotations.*;
import realdb.GhettoJdbcBlackBox;

public class Handler implements InvocationHandler {

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        // PART I -- use TableCreateWithDB project as a reference
        
        // get @MappedClass
        Class<?> mapperClass = method.getDeclaringClass();
        if (!mapperClass.isAnnotationPresent(MappedClass.class)) {
            throw new IllegalStateException("Missing @MappedClass annotation on " + mapperClass.getName());
        }
        Class<?> mappedClass = mapperClass.getAnnotation(MappedClass.class).clazz();

        String sqlString = null;

        // get @Select, replace :table in string
        if (method.isAnnotationPresent(Select.class)) {
            sqlString = method.getAnnotation(Select.class).value();
            String tableName = mappedClass.getAnnotation(Table.class).name();
            sqlString = sqlString.replace(":table", tableName);
        } else {
            throw new IllegalStateException("Missing @Select annotation on method " + method.getName());
        }

        // get @Param and replace :XXX in select string
        for (int i = 0; i < method.getParameters().length; i++) {
            Parameter p = method.getParameters()[i];
            if (p.isAnnotationPresent(Param.class)) {
                String paramName = p.getAnnotation(Param.class).value();
                sqlString = sqlString.replace(":" + paramName, args[i].toString());
            }
        }

        // PART II - make sure that there is a jdbxblackbox DB present in mysql
        GhettoJdbcBlackBox jdbc = new GhettoJdbcBlackBox();
        jdbc.init("com.mysql.cj.jdbc.Driver", 
                  "jdbc:mysql://localhost:3306/jdbcblackbox?serverTimezone=Asia/Hong_Kong&useSSL=false", 
                  "root", 
                  "cruiserfj");
        List<HashMap<String, Object>> results = jdbc.runSQLQuery(sqlString);

        // process list based on getReturnType
        // a List return a list of Objects
        // an Object type will return a single object
        if (method.getReturnType() == List.class) {
            List<Object> returnValue = new ArrayList<>();
            for (HashMap<String, Object> result : results) {
                Object o = mappedClass.getDeclaredConstructor().newInstance(); // Create new instance of the mapped class
                
                // go through all the keys in the result
                for (String columnName : result.keySet()) {
                    // look for field that has a matching @Column name attribute 
                    for (Field field : mappedClass.getDeclaredFields()) {
                        if (field.isAnnotationPresent(Column.class)) {
                            String column = field.getAnnotation(Column.class).name();
                            if (column.equals(columnName)) {
                                field.setAccessible(true); // Make private fields accessible
                                field.set(o, result.get(columnName)); // Set the field value
                                break;
                            }
                        }
                    }
                }
                // add instance to the returnValue list
                returnValue.add(o);
            }
            
            return returnValue;
        } else {
            // if the return type is not a List
            // take the first result
            if (results.isEmpty()) {
                return null; // Return null if no results
            }
            HashMap<String, Object> result = results.get(0);

            Object o = mappedClass.getDeclaredConstructor().newInstance(); // Create new instance of the mapped class

            // go through all the keys in the result
            for (String columnName : result.keySet()) {
                // look for field that has a matching @Column name attribute 
                for (Field field : mappedClass.getDeclaredFields()) {
                    if (field.isAnnotationPresent(Column.class)) {
                        String column = field.getAnnotation(Column.class).name();
                        if (column.equals(columnName)) {
                            field.setAccessible(true); // Make private fields accessible
                            field.set(o, result.get(columnName)); // Set the field value
                            break;
                        }
                    }
                }
            }

            return o; // Return the populated object
        }
    }
}
