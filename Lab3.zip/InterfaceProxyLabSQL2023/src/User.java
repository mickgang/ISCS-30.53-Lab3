

// PUT ANNOTATIONS FOR FIELDS SIMILAR TO THE SAMPLE
// determine what SQL types and column names to use by looking at the UserMapper

import annotations.Table;
import annotations.Column;

@Table(name = "users") // Apply the @Table annotation and specify the table name
public class User {
    @Column(name = "id", sql = "BIGINT", primaryKey = true) // Specify column details
    private Long id;

    @Column(name = "first_name", sql = "VARCHAR(255)")
    private String firstName;

    @Column(name = "last_name", sql = "VARCHAR(255)")
    private String lastName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return String.format("User [id=%s, firstName=%s, lastName=%s]", id, firstName, lastName);
    }
}

