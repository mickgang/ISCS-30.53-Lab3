import processor.CreateProcessor;
import realdb.GhettoJdbcBlackBox;

public class CreateTester {
    public static void main(String[] args) {
        GhettoJdbcBlackBox jdbc = new GhettoJdbcBlackBox();
        jdbc.init("com.mysql.cj.jdbc.Driver", 
                  "jdbc:mysql://localhost:3306/jdbcblackbox?serverTimezone=Asia/Hong_Kong&useSSL=false", 
                  "root", 
                  "cruiserfj");

        String dropTableSQL = "DROP TABLE IF EXISTS users";
        jdbc.runSQL(dropTableSQL);  // This will remove the existing table if it exists

        String createTableSQL = "CREATE TABLE users (id BIGINT PRIMARY KEY, first_name VARCHAR(255), last_name VARCHAR(255))";
        jdbc.runSQL(createTableSQL);  // Create the table
    }
}
